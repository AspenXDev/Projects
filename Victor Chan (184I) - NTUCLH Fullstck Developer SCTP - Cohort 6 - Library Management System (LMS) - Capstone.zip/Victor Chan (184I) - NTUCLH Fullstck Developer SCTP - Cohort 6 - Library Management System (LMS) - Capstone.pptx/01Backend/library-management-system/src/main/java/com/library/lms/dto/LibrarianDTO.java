package com.library.lms.dto;

public record LibrarianDTO(
    Long id,
    String fullName,
    String email,
    String phone
) {}
