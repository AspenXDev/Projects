package com.library.lms.exception;

public class MemberNotFoundException extends RuntimeException {
    public MemberNotFoundException(String msg) { super(msg); }
}