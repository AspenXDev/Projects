package com.library.lms.exception;

public class ReservationNotFoundException extends RuntimeException {
    public ReservationNotFoundException(String msg) { super(msg); }
}