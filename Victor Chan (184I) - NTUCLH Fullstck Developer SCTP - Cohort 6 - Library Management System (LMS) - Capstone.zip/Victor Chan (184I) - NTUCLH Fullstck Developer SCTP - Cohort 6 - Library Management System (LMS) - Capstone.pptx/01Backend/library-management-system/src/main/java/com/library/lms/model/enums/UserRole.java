package com.library.lms.model.enums;

public enum UserRole {
	Members,
	Librarians
}
